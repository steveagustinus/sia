package model;

public class Enums {
    public enum Jurusan {
        Informatika, Sistem_Informasi, Teknik_Industri, Desain_Komunikasi_Visual, Akuntansi, Online_Business, Manajemen
    }
}
